let e = 0;
let j = document.querySelectorAll("li.tile").length;
document.querySelectorAll("li.tile").forEach(el => {
    el.style.filter = `hue-rotate(${e}deg) brightness(1.5) drop-shadow(2px 4px 6px gray)`;
    e += 360 / j;
})
document.querySelector(".column-right").style.marginTop = "-17.5%"
document.querySelector("#content .row").style.width = "67%";
document.querySelector("#content .row").style.margin = "unset";